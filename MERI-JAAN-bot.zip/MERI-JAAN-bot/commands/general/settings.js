/**
 * Settings Command - Show current bot settings
 */

const config = require('../../config');

const onOff = (v) => (v ? '✅ ON' : '❌ OFF');

module.exports = {
  name: 'settings',
  aliases: ['setting', 'botsettings'],
  category: 'general',
  description: 'Show current bot settings',
  usage: '.settings',

  async execute(sock, msg, args, extra) {
    try {
      const owner = Array.isArray(config.ownerName) ? config.ownerName[0] : config.ownerName;
      const number = Array.isArray(config.ownerNumber) ? config.ownerNumber[0] : config.ownerNumber;

      const text = [
        `╭━━『 *${config.botName} Settings* 』━━╮`,
        '',
        `🤖 *Bot Name:* ${config.botName}`,
        `👑 *Owner:* ${owner}`,
        `📞 *Owner Number:* wa.me/${number}`,
        `⚡ *Prefix:* ${config.prefix}`,
        `🔒 *Mode:* ${config.selfMode ? 'PRIVATE' : 'PUBLIC'}`,
        '',
        `👀 *Auto Read:* ${onOff(config.autoRead)}`,
        `⌨️ *Auto Typing:* ${onOff(config.autoTyping)}`,
        `🎴 *Auto Sticker:* ${onOff(config.autoSticker)}`,
        `❤️ *Auto React:* ${onOff(config.autoReact)}`,
        `📥 *Auto Download:* ${onOff(config.autoDownload)}`,
        '',
        `📢 *Channel:* ${config.social.channel}`,
        `👥 *Group:* ${config.social.group}`,
        `🎵 *TikTok:* ${config.social.tiktok}`,
        '',
        '╰━━━━━━━━━━━━━━━━━━╯'
      ].join('\n');

      await extra.reply(text);
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
