/**
 * Status Command - Show bot status (uptime, memory, platform)
 */

const os = require('os');
const config = require('../../config');

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400);
  const h = Math.floor((seconds % 86400) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  parts.push(`${s}s`);
  return parts.join(' ');
}

module.exports = {
  name: 'status',
  aliases: ['botstatus', 'stats'],
  category: 'general',
  description: 'Show bot status',
  usage: '.status',

  async execute(sock, msg, args, extra) {
    try {
      const start = Date.now();
      const mem = process.memoryUsage();
      const usedMB = (mem.rss / 1024 / 1024).toFixed(1);
      const totalMB = (os.totalmem() / 1024 / 1024).toFixed(0);
      const latency = Date.now() - start;
      const owner = Array.isArray(config.ownerName) ? config.ownerName[0] : config.ownerName;

      const text = [
        `╭━━『 *${config.botName} Status* 』━━╮`,
        '',
        '🟢 *Status:* Online',
        `👑 *Owner:* ${owner}`,
        `⏱️ *Uptime:* ${formatUptime(process.uptime())}`,
        `⚡ *Latency:* ${latency}ms`,
        `🧠 *Memory:* ${usedMB} MB / ${totalMB} MB`,
        `💻 *Platform:* ${os.platform()} (${os.arch()})`,
        `🟩 *Node:* ${process.version}`,
        `🔒 *Mode:* ${config.selfMode ? 'PRIVATE' : 'PUBLIC'}`,
        '',
        '╰━━━━━━━━━━━━━━━━━━╯'
      ].join('\n');

      await extra.reply(text);
    } catch (error) {
      await extra.reply(`❌ Error: ${error.message}`);
    }
  }
};
